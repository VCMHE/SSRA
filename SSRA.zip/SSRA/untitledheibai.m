% For functional medical image fusion

close all;  clear all;  clc;
addpath functions


D=cell2mat(struct2cell(load('D_180.mat')));

for index=1:1

path1           = [ 'D:\Users\Administrator\Desktop\da2\tno3\IRR\IR (' ,        num2str(index) ,        ').png' ]; 
path2          = [ 'D:\Users\Administrator\Desktop\da2\tno3\v\VIS (' ,        num2str(index) ,       ').png' ];

fuse_path = ['D:\Users\Administrator\Desktop\jjieguo\newtno\srsa',num2str(index),'.png'];

A=imread(path1);  B=imread(path2); 

Fuse_img1 = SSRAhuidu(B,A);

imshow(Fuse_img1);

%imwrite(Fuse_img2,fuse_path2);

end

