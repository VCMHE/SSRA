% For functional medical image fusion

close all;  clear all;  clc;
addpath functions




%D=cell2mat(struct2cell(load('D_180.mat')));

for index=4:4

path1           = [ 'D:\Users\Administrator\Desktop\da2\MFNET\testMFnew\ir\IR (' ,        num2str(index) ,        ').png' ]; 
path2          = [ 'D:\Users\Administrator\Desktop\da2\MFNET\testMFnew\ir\VIS (' ,        num2str(index) ,       ').png' ];

fuse_path = ['D:\Users\Administrator\Desktop\jjieguo\testmfnet\ssra',num2str(index),'.png'];

A=imread(path1);  B=imread(path2); 
Final_result = SSRA(B,A);

figure;imshow(Final_result);

end
