This paper is SSRA
Our code is publicly available at:https://github.com/VCMHE/SSRA.